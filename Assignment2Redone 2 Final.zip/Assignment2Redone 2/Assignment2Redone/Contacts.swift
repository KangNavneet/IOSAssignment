//
//  Contacts.swift
//  Assignment2Redone
//
//  Created by Josh Cambrian on 2020-11-24.
//

import Foundation

let nameKey = "name"
let phoneKey = "phone"
let favKey = "fav"
let imageKey = "image"
let contactListKey = "contacts_list"

class Contacts{
    
    var allContacts = [Person]()
    
    @discardableResult func createContact(name: String, phoneNumber: Int) -> Person{
        let newPerson = Person(name: name, phoneNumber: phoneNumber)
        
        let contactDict : Dictionary<String,Any> = [nameKey:name,phoneKey:phoneNumber]
        if var contacts = UserDefaults.standard.value(forKey: contactListKey) as? [Dictionary<String,Any>]{
            contacts.append(contactDict)
            UserDefaults.standard.setValue(contacts, forKey: contactListKey)
        }else{
            UserDefaults.standard.setValue([contactDict], forKey: contactListKey)
        }
        allContacts.append(newPerson)
        
        return newPerson
    }
    
}
