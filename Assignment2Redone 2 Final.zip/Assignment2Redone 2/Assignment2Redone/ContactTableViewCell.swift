//
//  ContactTableViewCell.swift
//  Assignment2Redone
//
//  Created by Josh Cambrian on 2020-11-24.
//

import UIKit

class ContactTableViewCell: UITableViewCell {

    @IBOutlet weak var contactName: UILabel!
    
    @IBOutlet weak var contactPhoneNumber: UILabel!
    
    @IBOutlet weak var isFavoriteImage: UIImageView!
    
    var doubleTapped : (() -> ())?
    var cellTapped : (() -> ())?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.contentView.isUserInteractionEnabled = true
        let doubleTapGest = UITapGestureRecognizer(target: self, action: #selector(cellDoubleTapped))
        doubleTapGest.numberOfTapsRequired = 2
        self.addGestureRecognizer(doubleTapGest)
        //
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(tapCell))
        singleTap.numberOfTapsRequired = 1
        self.addGestureRecognizer(singleTap)
        singleTap.require(toFail: doubleTapGest)
    }
    
    @objc func cellDoubleTapped(){
        self.doubleTapped?()
    }
    
    @objc func tapCell(){
        self.cellTapped?()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
