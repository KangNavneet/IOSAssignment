//
//  DetailViewController.swift
//  Assignment2Redone
//
//  Created by Josh Cambrian on 2020-11-24.
//

import UIKit

class DetailViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    var person: Person!
    var dictLocal : Dictionary<String,Any>!
    var selectedIndex = 0
    
    @IBOutlet weak var contactImage: UIImageView!
    @IBOutlet weak var favImage : UIImageView!
    @IBOutlet weak var contactName: UITextField!
    @IBOutlet weak var contactPhonenumber: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let tapGest = UITapGestureRecognizer(target: self, action: #selector(openImagePicker))
        tapGest.numberOfTapsRequired = 1
        self.contactImage.addGestureRecognizer(tapGest)
        self.contactImage.isUserInteractionEnabled = true
        //
        
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(markUnMarkFav))
        doubleTap.numberOfTapsRequired = 2
        self.contactImage.addGestureRecognizer(doubleTap)
        
        tapGest.require(toFail: doubleTap)
    }
    
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if person.image != nil {
            contactImage.image = person.image
        }
        contactName.text = person.name
        contactPhonenumber.text = String(person.phoneNumber)
        // if contact is favorite make heart filled and red
        favImage.isHidden = !person.isFavorite
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        person.image = contactImage.image
        person.name = contactName.text ?? "error"
        person.phoneNumber = Int(contactPhonenumber.text!) ?? 0
        person.isFavorite = !self.favImage.isHidden
        
        
        //update data in local
        if var tempDict = self.dictLocal{
            tempDict[nameKey] = person.name
            tempDict[phoneKey] = person.phoneNumber
            tempDict[favKey] = person.isFavorite
            if let img = person.image{
                tempDict[imageKey] = img.pngData()
            }
            if var localContacts = UserDefaults.standard.value(forKey: contactListKey) as? [Dictionary<String,Any>]{
                localContacts[self.selectedIndex] = tempDict
                UserDefaults.standard.setValue(localContacts, forKey: contactListKey)
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.

    }
    */

    //MARK:- Mark Image as favrite
    
    @objc func markUnMarkFav(){
        self.favImage.isHidden = !self.favImage.isHidden
    }
    
    //MARK:- Open image picker
    
    @objc func openImagePicker(){
        let imagePIcker = UIImagePickerController()
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            imagePIcker.sourceType = .camera
        }else{
            imagePIcker.sourceType = .photoLibrary
        }
        
        imagePIcker.allowsEditing = true
        imagePIcker.delegate = self
        self.present(imagePIcker, animated: true, completion: nil)
    }
    
    //MARK:- Image Picker delegate
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[.editedImage] as? UIImage
        self.contactImage.image = image
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    
}
